$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/resources/Features/loginPage.feature");
formatter.feature({
  "name": "To verify the login funtions",
  "description": "",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "name": "Verify the login details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.step({
  "name": "launch Broswer and URL",
  "keyword": "Given "
});
formatter.step({
  "name": "enter \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "When "
});
formatter.step({
  "name": "click login button",
  "keyword": "And "
});
formatter.step({
  "name": "Validate the result",
  "keyword": "Then "
});
formatter.examples({
  "name": "",
  "description": "",
  "keyword": "Examples",
  "rows": [
    {
      "cells": [
        "username",
        "password"
      ]
    },
    {
      "cells": [
        "vishnuprasand",
        "Vishnu@123"
      ]
    },
    {
      "cells": [
        "Vishnu",
        "prasand687465"
      ]
    }
  ]
});
formatter.scenario({
  "name": "Verify the login details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "launch Broswer and URL",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.launch_Broswer_and_URL()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "enter \"vishnuprasand\" and \"Vishnu@123\"",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.enter_and(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click login button",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.click_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Validate the result",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.validate_the_result()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "Verify the login details",
  "description": "",
  "keyword": "Scenario Outline"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "launch Broswer and URL",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefinition.launch_Broswer_and_URL()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "enter \"Vishnu\" and \"prasand687465\"",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.enter_and(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click login button",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.click_login_button()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Validate the result",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.validate_the_result()"
});
formatter.result({
  "error_message": "java.lang.AssertionError: searchHotel\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.assertTrue(Assert.java:41)\r\n\tat com.stepdefinition.StepDefinition.validate_the_result(StepDefinition.java:36)\r\n\tat ✽.Validate the result(file:src/test/resources/Features/loginPage.feature:7)\r\n",
  "status": "failed"
});
formatter.embedding("image/png", "embedded0.png", null);
formatter.after({
  "status": "passed"
});
});