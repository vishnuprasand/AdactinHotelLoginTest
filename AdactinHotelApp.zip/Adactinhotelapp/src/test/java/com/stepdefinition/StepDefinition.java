package com.stepdefinition;

import static org.junit.Assert.assertTrue;

import com.pojo.Login_page;
import com.ulitil.Base;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends Base {

	@Given("launch Broswer and URL")
	public void launch_Broswer_and_URL() {
		launchbroswer();
		max();
		launchuURL("https://adactinhotelapp.com/HotelAppBuild2/");
	}

	@When("enter username and password")
	public void enter_username_and_password() {
		Login_page e = new Login_page();
		e.getUsername().sendKeys("vishnuprasand");
		e.getPassword().sendKeys("Vishnu@123");
	}

	@When("click login button")
	public void click_login_button() {
		Login_page e = new Login_page();
		e.getLogin().click();
	}

	@Then("Validate the result")
	public void validate_the_result() {
		assertTrue("searchHotel", d.getCurrentUrl().contains("SearchHotel.php"));

	}

	@When("enter {string} and {string}")
	public void enter_and(String string, String string2) {
		Login_page e = new Login_page();
		e.getUsername().sendKeys(string);
		e.getPassword().sendKeys(string2);
	}
}
