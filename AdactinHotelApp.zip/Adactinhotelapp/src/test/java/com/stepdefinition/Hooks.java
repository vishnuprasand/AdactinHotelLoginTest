package com.stepdefinition;



import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.ulitil.Base;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks extends Base {

	@Before
	public void beforesenario(Scenario scenario) {
		System.out.println(scenario.getName());
	}
	
	
	
	@After()
	public void tearDown(Scenario scenario) {
		if (scenario.isFailed()) {
			// Take a screenshot...
			final byte[] screenshot = ((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES);
			// embed it in the report.
			scenario.embed(screenshot, "image/png");
		}
		d.close();
	}

}
