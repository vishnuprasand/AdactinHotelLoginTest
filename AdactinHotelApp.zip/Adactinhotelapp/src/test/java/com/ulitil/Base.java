package com.ulitil;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	public static WebDriver d;
	
	
	
	public  static void TakeSshot(String imgName) throws IOException {
			File srcFile= new File("C:\\Users\\ELCOT\\Pictures\\Saved Pictures\\"+imgName+".png");
			TakesScreenshot ts=(TakesScreenshot)d;
			File newfile = ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcFile, newfile);
	}
	
	public static void launchbroswer() {
		System.setProperty("webdriver.chrome.driver","E:\\eclipse-workspace\\Adactinhotelapp\\Drivers\\chromedriver.exe");
		d=new ChromeDriver();
	}
	public static void launchuURL(String Url) {
		d.get(Url);
	}
	public static void fill(WebElement element,String yourText) {
		element.sendKeys(yourText);
	}
	public static void max( ) {
		d.manage().window().maximize();
	}
	public static void handleWindows( ) {
	
	}
	
}
