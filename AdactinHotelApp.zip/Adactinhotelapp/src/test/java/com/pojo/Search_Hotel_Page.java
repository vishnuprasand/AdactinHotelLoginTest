package com.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ulitil.Base;

public class Search_Hotel_Page extends Base {

	public Search_Hotel_Page() {
		PageFactory.initElements(d, this);
	}
	
	@FindBy(name="location")
	private WebElement location;
	
	@FindBy(name="room_nos")
	private WebElement room_nos;
	
	@FindBy(name="datepick_in")
	private WebElement datepick_in;
	
	@FindBy(name="datepick_out")
	private WebElement datepick_out;
	
	@FindBy(name="adult_room")
	private WebElement adult_room;
	
}
